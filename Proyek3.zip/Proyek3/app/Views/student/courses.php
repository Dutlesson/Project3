<div class="card" style="background:linear-gradient(120deg,#f8f9fa 0%,#e0eaff 100%);">
    <h2 style="color:#007bff; margin-top:0;display:flex;align-items:center;gap:10px;">
        <img src="https://img.icons8.com/color/32/000000/classroom.png"> Daftar Courses
    </h2>
    <?php if(session()->getFlashdata('success')): ?>
        <p style="color:green; font-weight:500; margin-bottom:12px;">✅ <?= session()->getFlashdata('success') ?></p>
    <?php endif; ?>
    
    <style>
    .table {
        border: 1px solid #333;
    }
    .table th, .table td {
        border: 1px solid #333;   /* kasih garis antar kolom */
        padding: 8px;
        text-align: left;
    }
    .table th {
        background: #ddd; /* warna header */
    }
</style>
    <table class="table table-striped" style="width:100%; border-collapse:collapse; box-shadow:0 0 12px rgba(0,0,0,0.1);">
        <thead>
            <tr>
                <th>Kode</th>
                <th>Nama</th>
                <th>Deskripsi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($courses as $course): ?>
            <tr style="background:#f4faff;">
                <td><b><?= esc($course['course_code']) ?></b></td>
                <td><?= esc($course['course_name']) ?></td>
                <td><?= esc($course['description']) ?></td>
                <td><a href="<?= base_url('course/enroll/'.$course['id']) ?>">Enroll</a></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
