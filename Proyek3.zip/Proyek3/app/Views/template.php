<!DOCTYPE html>
<html>
<head>
    <title>Welcome Cyberpunk</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@700&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            min-height: 100vh;
            background: radial-gradient(circle at 60% 40%, #1a0033 0%, #0f2027 100%);
            font-family: 'Orbitron', 'Segoe UI', Arial, sans-serif;
            color: #00fff7;
            overflow-x: hidden;
        }
        .cyberpunk-grid {
            display: grid;
            grid-template-columns: 1fr 1.2fr;
            align-items: center;
            min-height: 100vh;
            max-width: 1100px;
            margin: 0 auto;
            position: relative;
        }
        .character-panel {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background: rgba(30, 0, 60, 0.7);
            border-right: 4px solid #ff00cc;
            box-shadow: 0 0 40px #ff00cc;
            padding: 60px 0;
            position: relative;
        }
        .cyberpunk-character {
            width: 220px;
            border-radius: 20px;
            border: 2px solid #00fff7;
            filter: drop-shadow(0 0 20px #ff00cc);
            margin-bottom: 32px;
            background: rgba(0,0,0,0.2);
        }
        .neon-bar {
            width: 80%;
            height: 8px;
            background: linear-gradient(90deg, #00fff7 0%, #ff00cc 100%);
            border-radius: 4px;
            box-shadow: 0 0 16px #ff00cc;
            margin: 16px 0;
            animation: pulse 2s infinite alternate;
        }
        @keyframes pulse {
            0% { opacity: 0.7; }
            100% { opacity: 1; }
        }
        .info-panel {
            background: rgba(20, 20, 40, 0.85);
            border-left: 4px solid #00fff7;
            box-shadow: 0 0 40px #00fff7;
            border-radius: 0 24px 24px 0;
            padding: 60px 48px;
            position: relative;
        }
        h1 {
            font-size: 2.5em;
            letter-spacing: 2px;
            margin-bottom: 24px;
            text-shadow: 0 0 12px #00fff7, 0 0 24px #ff00cc;
        }
        .desc {
            font-size: 1.2em;
            margin-bottom: 32px;
            line-height: 1.6;
        }
        .cyberpunk-btn {
            display: inline-block;
            padding: 14px 32px;
            margin: 0 12px 12px 0;
            font-size: 1em;
            font-family: inherit;
            color: #fff;
            background: linear-gradient(90deg, #ff00cc 0%, #00fff7 100%);
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 12px #ff00cc;
            cursor: pointer;
            text-transform: uppercase;
            letter-spacing: 2px;
            transition: transform 0.2s, box-shadow 0.2s;
            text-decoration: none;
        }
        .cyberpunk-btn:hover {
            transform: scale(1.08);
            box-shadow: 0 0 24px #00fff7;
        }
        .lines-bg {
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            pointer-events: none;
            z-index: 0;
        }
        .line {
            position: absolute;
            width: 2px;
            height: 100vh;
            background: linear-gradient(180deg, #ff00cc 0%, #00fff7 100%);
            opacity: 0.2;
            animation: moveLine 6s linear infinite;
        }
        .line:nth-child(1) { left: 20%; animation-delay: 0s;}
        .line:nth-child(2) { left: 40%; animation-delay: 2s;}
        .line:nth-child(3) { left: 60%; animation-delay: 4s;}
        @keyframes moveLine {
            0% { top: -100vh; }
            100% { top: 100vh; }
        }
        .btn-group {
            margin-bottom: 24px;
        }
    </style>
</head>
<body>
    <div class="cyberpunk-grid">
        <div class="character-panel">
            <img src="https://cdn.pixabay.com/photo/2020/04/17/17/33/cyberpunk-5051987_1280.png" alt="Cyberpunk Character" class="cyberpunk-character">
            <div class="neon-bar"></div>
            <div class="neon-bar"></div>
        </div>
        <div class="info-panel">
            <h1>Welcome to Cyberpunk Akademik!</h1>
            <div class="desc">
                Selamat datang di aplikasi akademik bergaya cyberpunk.<br>
                Rasakan atmosfer futuristik, neon, dan teknologi canggih.<br>
                <b>Jelajahi fitur-fitur inovatif kami!</b>
            </div>
            <div class="btn-group">
                <a href="<?= base_url('login') ?>" class="cyberpunk-btn">Login</a>
            </div>
        </div>
        <div class="lines-bg">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
    </div>
</body>
</html>
