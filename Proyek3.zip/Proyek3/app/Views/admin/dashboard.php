<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        body {
            background: radial-gradient(circle at 60% 40%, #1a0033 0%, #0f2027 100%);
            font-family: 'Orbitron', 'Segoe UI', Arial, sans-serif;
            color: #00fff7;
            margin: 20px;
        }
        h1, h2, h3, .section-title {
            color: #00fff7;
            text-shadow: 0 0 12px #00fff7, 0 0 24px #ff00cc;
            font-family: 'Orbitron', 'Segoe UI', Arial, sans-serif;
            letter-spacing: 2px;
        }
        .card, .dashboard-container, .form-section {
            background: rgba(20,20,40,0.92);
            border-radius: 18px;
            box-shadow: 0 0 32px #ff00cc;
            padding: 32px 36px;
            margin-bottom: 32px;
        }
        .table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #1a0033;
            box-shadow: 0 0 24px #00fff7;
            border-radius: 12px;
            overflow: hidden;
            color: #00fff7;
            font-family: inherit;
        }
        th {
            background: linear-gradient(90deg, #00fff7 0%, #ff00cc 100%);
            color: #fff;
            text-shadow: 0 0 8px #ff00cc, 0 0 4px #00fff7;
            font-size: 1.1em;
            border: none;
        }
        td {
            background: rgba(20,20,40,0.92);
            color: #fff;
            border-bottom: 1px solid #00fff7;
            font-size: 1em;
        }
        tr:nth-child(even) td {
            background: rgba(0,0,0,0.25);
        }
        tr:hover td {
            background: rgba(255,0,204,0.18);
            color: #ff00cc;
            transition: background 0.2s, color 0.2s;
        }
        a {
            color: #00fff7;
            background: linear-gradient(90deg, #ff00cc 0%, #00fff7 100%);
            padding: 6px 18px;
            border-radius: 8px;
            text-decoration: none;
            box-shadow: 0 0 8px #ff00cc;
            font-weight: bold;
            transition: background 0.2s, color 0.2s, box-shadow 0.2s;
            border: none;
        }
        a:hover {
            background: linear-gradient(90deg, #00fff7 0%, #ff00cc 100%);
            color: #ff00cc;
            box-shadow: 0 0 16px #00fff7;
        }
        .btn {
            padding: 6px 14px;
            border: none;
            border-radius: 6px;
            color: #fff;
            cursor: pointer;
            background: #007bff;
        }
        .btn:hover {
            opacity: 0.9;
        }
        .btn-danger {
            background: #dc3545;
        }
        input, textarea, select {
            background: rgba(30,0,60,0.7);
            color: #fff;
            border: 2px solid #00fff7;
            border-radius: 10px;
            box-shadow: 0 0 8px #00fff7;
            font-size: 1em;
            outline: none;
            transition: border 0.2s;
            padding: 8px;
            width: 100%;
        }
        input:focus, select:focus, textarea:focus {
            border: 2px solid #ff00cc;
            box-shadow: 0 0 16px #ff00cc;
        }
        button, .btn, .enroll-link {
            background: linear-gradient(90deg, #ff00cc 0%, #00fff7 100%);
            color: #fff;
            border: none;
            border-radius: 12px;
            box-shadow: 0 0 16px #ff00cc;
            cursor: pointer;
            text-transform: uppercase;
            letter-spacing: 2px;
            font-size: 1em;
            font-family: inherit;
            transition: transform 0.2s, box-shadow 0.2s, background 0.2s, color 0.2s;
        }
        button:hover, .btn:hover, .enroll-link:hover {
            background: linear-gradient(90deg, #00fff7 0%, #ff00cc 100%);
            color: #ff00cc;
            box-shadow: 0 0 32px #00fff7;
            transform: scale(1.05);
        }
    </style>
</head>
<body>

    <h1>🎓 Admin Dashboard</h1>

    <!-- Tambah Course -->
    <div class="card" style="background:linear-gradient(120deg,#e0eaff 0%,#f8f9fa 100%);">
        <div style="display:flex;align-items:center;justify-content:space-between;">
            <h2 style="color:#007bff;display:flex;align-items:center;gap:10px;">
                <img src="https://img.icons8.com/color/48/000000/admin-settings-male.png" style="vertical-align:middle;"> Admin Dashboard
            </h2>
            <span style="background:#007bff;color:#fff;padding:6px 18px;border-radius:20px;font-weight:500;">Admin</span>
        </div>
        <h3 style="margin-bottom:10px;color:#0056b3;">Tambah Course</h3>
        <form method="post" action="/admin/addCourse" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;max-width:500px;margin:0 auto;">
            <input type="text" name="course_code" placeholder="Kode" required>
            <input type="text" name="course_name" placeholder="Nama" required>
            <textarea name="description" placeholder="Deskripsi" style="grid-column:span 2;"></textarea>
            <button type="submit" class="btn" style="grid-column:span 2;">Tambah</button>
        </form>
        <hr style="margin:32px 0;">
        <h3 style="color:#0056b3;">Enroll Student ke Course</h3>
        <form method="post" action="/admin/enrollStudent" style="display:flex;gap:12px;align-items:center;max-width:500px;margin:0 auto;">
            <select name="student_id" required>
                <option value="">Pilih Student</option>
                <?php foreach($students as $s): ?>
                    <option value="<?= $s['id'] ?>"><?= $s['username'] ?> (<?= $s['nim'] ?? 'N/A' ?>)</option>
                <?php endforeach; ?>
            </select>
            <select name="course_id" required>
                <option value="">Pilih Course</option>
                <?php foreach($courses as $c): ?>
                    <option value="<?= $c['id'] ?>"><?= $c['course_code'] ?> - <?= $c['course_name'] ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn">Enroll</button>
        </form>
    </div>

    <!-- Daftar Courses -->
    <div class="card" style="background:linear-gradient(120deg,#f8f9fa 0%,#e0eaff 100%);">
        <h3 style="color:#007bff;display:flex;align-items:center;gap:8px;">
            <img src="https://img.icons8.com/color/32/000000/classroom.png"> Daftar Courses
        </h3>
        <table class="table">
            <thead>
                <tr>
                    <th>Kode</th>
                    <th>Nama</th>
                    <th>Deskripsi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($courses as $course): ?>
                <tr>
                    <td><b><?= esc($course['course_code']) ?></b></td>
                    <td><?= esc($course['course_name']) ?></td>
                    <td><?= esc($course['description']) ?></td>
                    <td><a href="<?= base_url('course/enroll/'.$course['id']) ?>">Enroll</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Daftar Students -->
    <div class="card" style="background:linear-gradient(120deg,#e0eaff 0%,#f8f9fa 100%);">
        <h3 style="color:#007bff;display:flex;align-items:center;gap:8px;">
            <img src="https://img.icons8.com/color/32/000000/student-male--v2.png"> Daftar Students
        </h3>
        <table class="table">
            <tr>
                <th>Username</th>
                <th>NIM</th>
                <th>Aksi</th>
            </tr>
            <?php foreach($students as $s): ?>
            <tr>
                <td><b><?= $s['username'] ?></b></td>
                <td><?= $s['nim'] ?? 'N/A' ?></td>
                <td>
                    <form method="post" action="/admin/deleteStudent" style="display:inline;" onsubmit="return confirm('Yakin ingin menghapus student ini?');">
                        <input type="hidden" name="student_id" value="<?= $s['id'] ?>">
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>

</body>
</html>
