<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login Cyberpunk</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@700&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Orbitron', Arial, sans-serif;
            background: radial-gradient(circle at 60% 40%, #1a0033 0%, #0f2027 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #00fff7;
        }
        .login-box {
            width: 370px;
            padding: 36px 32px;
            background: rgba(20, 20, 40, 0.92);
            border-radius: 20px;
            box-shadow: 0 0 32px #ff00cc, 0 0 8px #00fff7 inset;
            text-align: center;
            position: relative;
            border: 2px solid #ff00cc;
        }
        .login-box h2 {
            margin-bottom: 22px;
            color: #00fff7;
            font-size: 2em;
            text-shadow: 0 0 12px #00fff7, 0 0 24px #ff00cc;
            letter-spacing: 2px;
        }
        .login-box input {
            width: 100%;
            padding: 13px;
            margin: 12px 0;
            border: 2px solid #00fff7;
            border-radius: 10px;
            background: rgba(30,0,60,0.7);
            color: #fff;
            font-size: 15px;
            box-shadow: 0 0 8px #00fff7;
            outline: none;
            transition: border 0.2s;
        }
        .login-box input:focus {
            border: 2px solid #ff00cc;
            box-shadow: 0 0 16px #ff00cc;
        }
        .login-box button {
            width: 100%;
            padding: 14px 0;
            margin-top: 14px;
            background: linear-gradient(90deg, #ff00cc 0%, #00fff7 100%);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-size: 1.1em;
            font-family: inherit;
            cursor: pointer;
            text-transform: uppercase;
            letter-spacing: 2px;
            box-shadow: 0 0 16px #ff00cc;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .login-box button:hover {
            transform: scale(1.05);
            box-shadow: 0 0 32px #00fff7;
        }
        .error {
            margin-bottom: 14px;
            color: #ff00cc;
            font-size: 15px;
            background: rgba(255,0,204,0.08);
            border-radius: 8px;
            padding: 8px 0;
            box-shadow: 0 0 8px #ff00cc;
        }
        .login-logo {
            display: block;
            margin: 0 auto 22px auto;
            width: 80px;
            filter: drop-shadow(0 0 16px #00fff7);
            border-radius: 50%;
            border: 2px solid #ff00cc;
            background: rgba(0,0,0,0.2);
        }
        .neon-bar {
            width: 60%;
            height: 7px;
            background: linear-gradient(90deg, #00fff7 0%, #ff00cc 100%);
            border-radius: 3px;
            box-shadow: 0 0 12px #ff00cc;
            margin: 18px auto;
            animation: pulse 2s infinite alternate;
        }
        @keyframes pulse {
            0% { opacity: 0.7; }
            100% { opacity: 1; }
        }
        .back-link {
            display: block;
            margin: 24px auto 0 auto;
            text-align: center;
            color: #00fff7;
            text-decoration: underline;
            font-size: 1em;
            transition: color 0.2s;
        }
        .back-link:hover {
            color: #ff00cc;
        }
        .login-box {
            animation: fadeInDown 0.7s;
        }
        @keyframes fadeInDown {
            from { opacity:0; transform:translateY(-40px); }
            to { opacity:1; transform:translateY(0); }
        }
    </style>
</head>
<body>
    <div class="login-box">
        <img src="https://cdn.pixabay.com/photo/2020/04/17/17/33/cyberpunk-5051987_1280.png" alt="Logo" class="login-logo">
        <div class="neon-bar"></div>
        <h2>Login</h2>

        <?php if(session()->getFlashdata('error')): ?>
            <p class="error"><?= session()->getFlashdata('error') ?></p>
        <?php endif; ?>

        <form method="post" action="/login/auth">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <a href="<?= base_url('/') ?>" class="back-link">← Kembali ke Home</a>
    </div>
</body>
</html>
