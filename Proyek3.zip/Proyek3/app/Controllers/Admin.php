<?php

namespace App\Controllers;

use App\Models\CourseModel;
use App\Models\UserModel;

class Admin extends BaseController
{
    public function index()
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to('/login')->with('error', 'Akses ditolak!');
        }

        $courseModel = new CourseModel();
        $courses = $courseModel->findAll();

        $userModel = new UserModel();
        $students = $userModel->where('role', 'student')->findAll();

        return view('admin/dashboard', [
            'courses' => $courses,
            'students' => $students
        ]);
    }

    public function addCourse()
    {
        $courseModel = new CourseModel();
        $courseModel->insert([
            'course_code' => $this->request->getPost('course_code'),
            'course_name' => $this->request->getPost('course_name'),
            'description' => $this->request->getPost('description'),
        ]);
        return redirect()->to('/admin')->with('success', 'Course ditambahkan!');
    }

    public function deleteStudent()
    {
        $userModel = new UserModel();
        $id = $this->request->getPost('student_id');
        $userModel->delete($id);
        return redirect()->to('/admin')->with('success', 'Student berhasil dihapus!');
    }

    public function deleteCourse()
    {
        $courseModel = new CourseModel();
        $id = $this->request->getPost('course_id');
        $courseModel->delete($id);
        return redirect()->to('/admin')->with('success', 'Course berhasil dihapus!');
    }

    public function enrollStudent()
    {
        $student_id = $this->request->getPost('student_id');
        $course_id = $this->request->getPost('course_id');
        $enrollModel = new \App\Models\EnrollmentModel();
        $enrollModel->insert([
            'user_id' => $student_id,
            'course_id' => $course_id
        ]);
        return redirect()->to('/admin')->with('success', 'Student berhasil di-enroll ke course!');
    }
}
